package com.epiloksa.news.ui.news

data class CategoryModel (
        val id: String,
        val name: String,
)
